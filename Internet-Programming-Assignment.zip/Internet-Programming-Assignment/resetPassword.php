<?php
$email = trim(filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL));
$newPassword = trim(filter_input(INPUT_POST, 'newPassword'));
$confirmPassword = trim(filter_input(INPUT_POST, 'confirmPassword'));

if (!empty($email) && !empty($newPassword) && !empty($confirmPassword)) {
    if ($newPassword !== $confirmPassword) {
        echo json_encode(['status' => 'error', 'message' => 'Passwords do not match.']);
        exit;
    }

    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "healthcare";

    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        die(json_encode(['status' => 'error', 'message' => 'Connection Error: ' . $conn->connect_error]));
    } else {
        // Check if email exists
        $stmt = $conn->prepare("SELECT * FROM `new account` WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            echo json_encode(['status' => 'error', 'message' => 'Email not found.']);
            $stmt->close();
            $conn->close();
            exit;
        }
        
        $stmt->close();

        $stmt = $conn->prepare("UPDATE `new account` SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $newPassword, $email);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Password reset successful.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error: ' . $stmt->error]);
        }

        $stmt->close();
        $conn->close();
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Please fill in all fields.']);
}
?>
