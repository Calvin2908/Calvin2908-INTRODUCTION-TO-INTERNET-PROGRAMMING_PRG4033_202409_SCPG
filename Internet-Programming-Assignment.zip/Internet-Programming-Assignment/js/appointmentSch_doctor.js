document.addEventListener('DOMContentLoaded', function () {
    fetchDoctorInfo()
        .then(doctorData => {
            if (doctorData.user_type === 'doctor') {
                fetchDoctorAppointments(doctorData.username)
                    .then(appointments => {
                        displayAppointments(appointments);
                    })
                    .catch(error => {
                        console.error('Error fetching appointments:', error);
                        showErrorMessage('Error loading appointments');
                    });
            } else {
                console.error('Error: User is not a doctor');
                showErrorMessage('You are not authorized to view this page.');
            }
        })
        .catch(error => {
            console.error('Error getting doctor information:', error);
            showErrorMessage('Error getting doctor information');
        });
});

function fetchDoctorInfo() {
    return fetch('appointmentSch_doctor.php?action=get_doctor', {
        credentials: 'include'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'error') {
            throw new Error(data.message);
        }
        return {
            username: data.username,
            user_type: data.user_type,
        };
    });
}

function fetchDoctorAppointments(doctorUsername) {
    return fetch(`appointmentSch_doctor.php?action=fetch_appointments&doctor_username=${doctorUsername}`, {
        credentials: 'include'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'error') {
            throw new Error(data.message);
        }
        return data.appointments;
    });
}

function displayAppointments(appointments) {
    const container = document.getElementById('appointment-container');
    container.innerHTML = '';

    if (appointments.length === 0) {
        container.innerHTML = '<p>No appointments scheduled.</p>';
        return;
    }

    appointments.forEach(appointment => {
        const card = createAppointmentCard(appointment);
        container.appendChild(card);
    });
}

function createAppointmentCard(appointment) {
    const card = document.createElement('div');
    card.classList.add('patientcard');
    card.setAttribute('data-appointment-id', appointment.id);
    card.innerHTML = `
        <div class="patientInfo">
            <div>
                <label class="infoHead">Name</label>
                <input type="text" value="${appointment.patient_name}" class="txtfieldshort" disabled>
            </div>
            <div>
                <label class="infoHead">NRIC</label>
                <input type="text" value="${appointment.nric_passport_no}" class="txtfieldshort" disabled>
            </div>
            <div>
                <label class="infoHead">Date</label>
                <input type="text" value="${appointment.appointment_date}" class="txtfieldshort" disabled>
            </div>
            <div>
                <label class="infoHead">Time</label>
                <input type="text" value="${appointment.appointment_time}" class="txtfieldshort" disabled>
            </div>
            <div>
                <label class="infoHead">Email</label>
                <input type="text" value="${appointment.email}" class="txtfieldshort" disabled>
            </div>
            <div>
                <label class="infoHead">Contact Number</label>
                <input type="text" value="${appointment.contact_number}" class="txtfieldshort" disabled>
            </div>
            <div>
                <label class="infoHead">Doctor Name</label>
                <input type="text" value="${appointment.doctor_id || 'Not Assigned'}" class="txtfieldshort" disabled>
            </div>
        </div>
        <div class="buttons">
            <button class="cancel-btn" onclick="handleAppointment(${appointment.id}, 'cancel')">Cancel</button>
            <button class="complete-btn" onclick="handleAppointment(${appointment.id}, 'complete')">Mark as Completed</button>
        </div>
    `;
    return card;
}

function handleAppointment(appointmentId, action) {
    // Only show the confirmation if the action is 'cancel'
    if (action === 'cancel') {
        const isConfirmed = confirm('Are you sure you want to cancel this appointment?');
        if (!isConfirmed) {
            return;
        }
    }

    // Set the status based on the action
    const status = action === 'cancel' ? 'cancelled' :
                  action === 'complete' ? 'completed' : 'accepted';

    // Proceed with the API call to update the appointment status
    fetch('appointmentSch_doctor.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `action=update_appointment&appointment_id=${appointmentId}&status=${status}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            fetchDoctorInfo()
                .then(doctorData => fetchDoctorAppointments(doctorData.username))
                .then(displayAppointments);
            
            // If the appointment is cancelled, send the cancel email
            if (action === 'cancel') {
                sendCancelEmail(appointmentId);
            }
        } else {
            showErrorMessage(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showErrorMessage('An error occurred');
    });
}


function sendCancelEmail(appointmentId) {
    fetch('sendmail.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `appointmentId=${appointmentId}&action=cancel`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'error') {
            console.error('Error sending email:', data.message);
        }
    })
    .catch(error => {
        console.error('Error sending email:', error);
    });
}

function showErrorMessage(message) {
    const container = document.getElementById('appointment-container');
    container.innerHTML = `<p style="color: red;">${message}</p>`;
}
