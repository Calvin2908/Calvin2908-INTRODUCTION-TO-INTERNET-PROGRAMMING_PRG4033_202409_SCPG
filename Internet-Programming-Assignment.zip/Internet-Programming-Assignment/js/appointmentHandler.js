// Fetch appointments from the PHP script
fetch('patientEmail_admin.php')
    .then(response => response.json())
    .then(appointments => {
        const container = document.getElementById('appointment-container');

        appointments.forEach(appointment => {
            const card = document.createElement('div');
            card.classList.add('card');
            card.setAttribute('data-appointment-id', appointment.id);

            card.innerHTML = `
                <div class="card-content">
                    <div>
                        <label class="infoHead">Name</label>
                        <input type="text" value="${appointment.patient_name}" class="txtfieldshort" disabled>
                    </div>
                    <div>
                        <label class="infoHead">NRIC</label>
                        <input type="text" value="${appointment.nric_passport_no}" class="txtfieldshort" disabled>
                    </div>
                    <div>
                        <label class="infoHead">Date</label>
                        <input type="text" value="${appointment.appointment_date}" class="txtfieldshort" disabled>
                    </div>
                    <div>
                        <label class="infoHead">Time</label>
                        <input type="text" value="${appointment.appointment_time}" class="txtfieldshort" disabled>
                    </div>
                    <div>
                        <label class="infoHead">Email</label>
                        <input type="text" value="${appointment.email}" class="txtfieldshort" disabled>
                    </div>
                    <div>
                        <label class="infoHead">Contact Number</label>
                        <input type="text" value="${appointment.contact_number}" class="txtfieldshort" disabled>
                    </div>
                    <div>
                        <label>Doctor Name</label>
                        <input type="text" value="${appointment.doctor_id || 'Not Assigned'}" disabled>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="cancel-btn" onclick="handleAppointment(${appointment.id}, 'cancel')">Cancel</button>
                    <button class="accept-btn" onclick="handleAppointment(${appointment.id}, 'accept')">Accept</button>
                </div>
            `;
            container.appendChild(card);
        });
    })
    .catch(error => console.error('Error fetching appointments:', error));

    function handleAppointment(appointmentId, action) {
        // Confirm action
        const confirmMessage = action === 'accept' 
            ? 'Are you sure you want to accept this appointment?' 
            : 'Are you sure you want to cancel this appointment?';
        
        if (!confirm(confirmMessage)) {
            return;
        }
    
        // Send AJAX request
        fetch('sendmail.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `appointmentId=${appointmentId}&action=${action}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Remove the appointment card from the UI
                const card = document.querySelector(`[data-appointment-id="${appointmentId}"]`);
                if (card) {
                    card.remove();
                }
                
                // Show success message
                alert(data.message);
            } else {
                // Show error message
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An unexpected error occurred');
        });
    }
