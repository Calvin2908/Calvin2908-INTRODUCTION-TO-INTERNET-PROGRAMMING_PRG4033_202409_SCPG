document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('loginForm');
    const loginButton = form.querySelector('.login-button');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');

    // Add event listener to the login button
    loginButton.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default form submission

        // Validate inputs
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        if (!username || !password) {
            alert('Please enter both username and password.');
            return;
        }

        // Create FormData
        const formData = new FormData();
        formData.append('username', username);
        formData.append('password', password);

        // Send login request
        fetch('login.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json()) // Parse JSON response
        .then(data => {
            // Debug: Log the full response
            console.log('Server response:', data);

            if (data.status === 'success') {
                // Redirect to the appropriate home page based on user type
                window.location.href = data.redirect;
            } else {
                // Show error message
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    });
});
