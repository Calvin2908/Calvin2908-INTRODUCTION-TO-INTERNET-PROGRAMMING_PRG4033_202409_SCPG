document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('account-container');

    // Fetch account requests
    fetch('accountRequest_admin.php')
        .then(response => response.json())
        .then(accounts => {
            if (Array.isArray(accounts)) {
                accounts.forEach(account => {
                    const card = document.createElement('div');
                    card.classList.add('card');
                    card.setAttribute('data-account-id', account.Id);

                    card.innerHTML = `
                        <div class="card-content">
                            <div>
                                <label>Username</label>
                                <input type="text" value="${account.username}" class="txtfieldshort" disabled>
                            </div>
                            <div>
                                <label>Email</label>
                                <input type="text" value="${account.email}" class="txtfieldshort" disabled>
                            </div>
                            <div>
                                <label>Position</label>
                                <input type="text" value="${account.user_type}" class="txtfieldshort" disabled>
                            </div>
                        </div>
                        <div class="card-actions">
                            <button class="cancel-btn" onclick="handleRequest(${account.Id}, 'cancel')">Cancel</button>
                            <button class="accept-btn" onclick="handleRequest(${account.Id}, 'accept')">Accept</button>
                        </div>
                    `;
                    container.appendChild(card);
                });
            }
        })
        .catch(error => console.error('Error fetching accounts:', error));
});

function handleRequest(accountId, action) {
    const confirmMessage = action === 'accept' ?
        'Are you sure you want to accept this request?' :
        'Are you sure you want to cancel this request?';

    if (!confirm(confirmMessage)) return;

    // Send the request to update the approval status
    fetch('accountRequest_admin.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `accountId=${accountId}&action=${action}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            const card = document.querySelector(`[data-account-id="${accountId}"]`);
            if (card) card.remove(); // Remove the card from the UI after the action
            alert(data.message);
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An unexpected error occurred');
    });
}
