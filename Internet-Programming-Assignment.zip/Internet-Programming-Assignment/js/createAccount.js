document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('createAccountForm');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Validate user type selection
        const userTypeSelected = document.querySelector('input[name="userType"]:checked');
        if (!userTypeSelected) {
            alert('Please select a user type.');
            return;
        }

        const formData = new FormData(form);

        fetch('createAccount.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            // Check for success
            if (data.trim() === 'success') {
                form.reset();
                alert('Registration successful! Your account has been created.');
                window.location.href = 'login.html';
            } 
            // Handle any other response errors
            else {
                alert(data);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    });
});
