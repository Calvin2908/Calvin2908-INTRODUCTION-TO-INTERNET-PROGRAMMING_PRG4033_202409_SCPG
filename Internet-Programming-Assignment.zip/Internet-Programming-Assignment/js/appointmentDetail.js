const daysTag = document.querySelector(".days");
const currentDate = document.querySelector(".currentDate");
const prevNextIcon = document.querySelectorAll(".icons i");

let date = new Date();
let currYear = date.getFullYear();
let currMonth = date.getMonth();

const months = ["January", "February", "March", "April", "May", "June", "July",
              "August", "September", "October", "November", "December"];

let selectedDate = null;
let selectedTime = null;

const unavailableTimeSlots = [
    "10:00 AM", "11:00 AM", "12:30 PM", "2:00 PM", "3:30 PM", "6:00 PM"
];

function showUnavailableSlotModal(timeSlot) {
    const modal = document.getElementById('unavailableModal');
    const modalMessage = document.getElementById('modalMessage');
    const closeModalBtn = document.querySelector('.modal-close-btn');

    modalMessage.textContent = `Sorry, the time slot ${timeSlot} is not available.`;
    modal.style.display = 'flex';

    const closeModal = () => modal.style.display = 'none';

    closeModalBtn?.addEventListener('click', closeModal);
    modal.addEventListener('click', (event) => {
        if (event.target === modal) closeModal();
    });
}

function renderCalendar() {
    const firstDayofMonth = new Date(currYear, currMonth, 1).getDay();
    const lastDateofMonth = new Date(currYear, currMonth + 1, 0).getDate();
    const lastDayofMonth = new Date(currYear, currMonth, lastDateofMonth).getDay();
    const lastDateofLastMonth = new Date(currYear, currMonth, 0).getDate();

    let liTag = "";

    for (let i = firstDayofMonth; i > 0; i--) {
        liTag += `<li class="inactive">${lastDateofLastMonth - i + 1}</li>`;
    }

    const today = new Date();
    for (let i = 1; i <= lastDateofMonth; i++) {
        const isSelected = selectedDate && 
                          selectedDate.getFullYear() === currYear && 
                          selectedDate.getMonth() === currMonth && 
                          selectedDate.getDate() === i;
        
        const isToday = i === today.getDate() && 
                        currMonth === today.getMonth() && 
                        currYear === today.getFullYear();

        const isPastDate = new Date(currYear, currMonth, i) < new Date(today.setHours(0, 0, 0, 0));
        
        const classes = [
            isToday ? "today" : "",
            isSelected ? "selected" : "",
            isPastDate ? "inactive" : ""
        ].filter(Boolean);
        
        liTag += `<li class="${classes.join(" ")}" data-date="${i}">${i}</li>`;
    }

    for (let i = lastDayofMonth; i < 6; i++) {
        liTag += `<li class="inactive">${i - lastDayofMonth + 1}</li>`;
    }

    currentDate.innerText = `${months[currMonth]} ${currYear}`;
    daysTag.innerHTML = liTag;
    addDayClickListeners();
}

function addDayClickListeners() {
    const dayElements = document.querySelectorAll('.calendar .days li:not(.inactive)');
    dayElements.forEach(day => {
        day.addEventListener('click', () => {
            const isAlreadySelected = day.classList.contains('selected');
            
            document.querySelector('.calendar .days li.selected')?.classList.remove('selected');
            
            if (!isAlreadySelected) {
                day.classList.add('selected');
                const dayNum = parseInt(day.dataset.date);
                selectedDate = new Date(currYear, currMonth, dayNum);
            } else {
                selectedDate = null;
            }
            
            updateDateTimeDisplay();
        });
    });
}

function addTimeSlotListeners() {
    const timeSlots = document.querySelectorAll('.timeButton, .timeButtonUnavailable');
    timeSlots.forEach(slot => {
        slot.addEventListener('click', (e) => {
            e.preventDefault();
            
            if (slot.classList.contains('timeButtonUnavailable')) {
                showUnavailableSlotModal(slot.textContent);
                return;
            }

            const isAlreadySelected = slot.classList.contains('timeButtonSelected');
            document.querySelector('.timeButtonSelected')?.classList.remove('timeButtonSelected');
            
            if (!isAlreadySelected ) {
                slot.classList.add('timeButtonSelected');
                selectedTime = slot.textContent;
            } else {
                selectedTime = null;
            }
            
            updateDateTimeDisplay();
        });
    });
}

function updateDateTimeDisplay() {
    const selectedDateDisplay = document.getElementById('selectedDateDisplay');
    if (!selectedDateDisplay) return;

    if (selectedDate && selectedTime) {
        const formattedDate = selectedDate.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        selectedDateDisplay.textContent = `Appointment: ${formattedDate} at ${selectedTime}`;
    } else if (selectedDate) {
        const formattedDate = selectedDate.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        selectedDateDisplay.textContent = `Selected Date: ${formattedDate}`;
    } else if (selectedTime) {
        selectedDateDisplay.textContent = `Selected Time: ${selectedTime}`;
    } else {
        selectedDateDisplay.textContent = 'No date or time selected';
    }
}

function validateForm() {
    const requiredFields = ['name', 'ic', 'email', 'contactnum'];
    let isValid = true;

    requiredFields.forEach(field => {
        const input = document.querySelector(`input[name="${field}"]`);
        if (!input?.value) {
            input.classList.add('error'); // Add error class for styling
            isValid = false;
        } else {
            input.classList.remove('error'); // Remove error class if valid
        }
    });

    if (!selectedDate || !selectedTime) {
        isValid = false;
        alert('Please select both a date and time for your appointment.'); // Alert for date/time selection
    }

    return isValid; // Return the validity of the form
}

prevNextIcon.forEach(icon => {
    icon.addEventListener("click", () => {
        currMonth = icon.id === "prev" ? currMonth - 1 : currMonth + 1;

        if (currMonth < 0 || currMonth > 11) {
            date = new Date(currYear, currMonth, new Date().getDate());
            currYear = date.getFullYear();
            currMonth = date.getMonth();
        }
        renderCalendar();
    });
});

document.querySelector('.submitButton')?.addEventListener('click', function(event) {
    event.preventDefault();

    // Validate the form before proceeding
    if (!validateForm()) return;

    const formData = new FormData();
    formData.append('selectedDate', selectedDate.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }));
    formData.append('selectedTime', selectedTime);
    formData.append('name', document.querySelector('input[name="name"]').value);
    formData.append('ic', document.querySelector('input[name="ic"]').value);
    formData.append('email', document.querySelector('input[name="email"]').value);
    formData.append('contact', document.querySelector('input[name="contactnum"]').value);
    formData.append('doctorId', new URLSearchParams(window.location.search).get("doctor"));

    fetch('booking_process.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result === 'success') {
            // Show success message and redirect after closing the alert
            alert('Appointment booked successfully!');
            // Clear the form fields
            document.getElementById('appointmentForm').reset();
            selectedDate = null; // Reset selected date
            selectedTime = null; // Reset selected time
            updateDateTimeDisplay(); // Update the display to show no selection
            
            // Redirect after alert is closed
            setTimeout(() => {
                window.location.href = 'bookappointment.html';
            }, 100); // Delay to allow the alert to be acknowledged
        } else {
            alert(result);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const doctorName = urlParams.get('doctor');
    
    if (doctorName) {
        document.querySelector('.doctorName').textContent = doctorName;
        document.getElementById('doctorId').value = doctorName;  // Ensure this is the ID for doctor
    }
    
    renderCalendar();
    addTimeSlotListeners();
});