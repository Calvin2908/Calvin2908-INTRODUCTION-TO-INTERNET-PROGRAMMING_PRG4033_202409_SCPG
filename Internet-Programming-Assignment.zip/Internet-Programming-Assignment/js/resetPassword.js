document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('resetForm');
    const resetButton = form.querySelector('.forget-button');
    const emailInput = document.getElementById('email');
    const newPasswordInput = document.getElementById('newPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');

    // Add event listener to the reset button
    resetButton.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default form submission

        // Validate inputs
        const email = emailInput.value.trim();
        const newPassword = newPasswordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();

        if (!email || !newPassword || !confirmPassword) {
            alert('Please fill in all fields.');
            return;
        }

        if (newPassword !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        // Create FormData
        const formData = new FormData();
        formData.append('email', email);
        formData.append('newPassword', newPassword);
        formData.append('confirmPassword', confirmPassword);

        // Send password reset request
        fetch('resetPassword.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json()) // Parse JSON response
        .then(data => {
            // Debug: Log the full response
            console.log('Server response:', data);

            if (data.status === 'success') {
                alert(data.message);
                window.location.href = 'login.html';
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    });
});
