<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'healthcare';

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle appointment acceptance
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['appointmentId']) && isset($_POST['action'])) {
            $appointmentId = $_POST['appointmentId'];
            $action = $_POST['action'];

            // Update appointment status
            $updateStmt = $pdo->prepare("UPDATE appointments SET status = :status WHERE id = :id");
            $status = ($action === 'accept') ? 'confirmed' : 'cancelled';
            $updateStmt->bindParam(':status', $status);
            $updateStmt->bindParam(':id', $appointmentId, PDO::PARAM_INT);
            $updateStmt->execute();

            // Return success response
            echo json_encode([
                'status' => 'success', 
                'message' => ($action === 'accept'),
                'redirect' => 'appointmetSch.php'
            ]);
        } else {
            echo json_encode([
                'status' => 'error', 
                'message' => 'Invalid request parameters'
            ]);
        }
    }
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error', 
        'message' => $e->getMessage()
    ]);
}
?>