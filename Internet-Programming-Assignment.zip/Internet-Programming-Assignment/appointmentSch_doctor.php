<?php
session_start();

header('Content-Type: application/json');

// Database configuration
$db_host = 'localhost';
$db_name = 'healthcare';
$db_user = 'root';
$db_pass = '';

function connectDatabase() {
    global $db_host, $db_user, $db_pass, $db_name;
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
        exit;
    }
    return $conn;
}

$action = $_GET['action'] ?? $_POST['action'] ?? null;

// Check session
if (!isset($_SESSION['username']) || !isset($_SESSION['usertype'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

switch ($action) {
    case 'get_doctor':
        if ($_SESSION['usertype'] !== 'doctor') {
            echo json_encode(['status' => 'error', 'message' => 'User is not a doctor']);
            exit;
        }

        echo json_encode([
            'status' => 'success',
            'username' => $_SESSION['username'],
            'user_type' => $_SESSION['usertype']
        ]);
        break;

    case 'fetch_appointments':
        $doctor_username = $_GET['doctor_username'] ?? null;
        if (!$doctor_username) {
            echo json_encode(['status' => 'error', 'message' => 'Doctor username is missing']);
            exit;
        }

        $conn = connectDatabase();
        $sql = "SELECT * FROM appointments WHERE doctor_id = ? AND (status = 'accepted') ORDER BY appointment_date, appointment_time";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $doctor_username);
        $stmt->execute();
        $result = $stmt->get_result();

        $appointments = [];
        while ($row = $result->fetch_assoc()) {
            $appointments[] = $row;
        }

        echo json_encode(['status' => 'success', 'appointments' => $appointments]);

        $stmt->close();
        $conn->close();
        break;

    case 'update_appointment':
        $appointment_id = $_POST['appointment_id'] ?? null;
        $status = $_POST['status'] ?? null;

        if (!$appointment_id || !$status) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
            exit;
        }

        $conn = connectDatabase();
        $sql = "UPDATE appointments SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $appointment_id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Appointment updated']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update appointment']);
        }

        $stmt->close();
        $conn->close();
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
        break;
}
?>