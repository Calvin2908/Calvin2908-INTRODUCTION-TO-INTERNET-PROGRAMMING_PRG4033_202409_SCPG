<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'healthcare';

function sendPatientEmail($appointmentId, $action) {
    global $host, $username, $password, $db_name;

    try {
        // Create PDO connection
        $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Fetch appointment details
        $stmt = $pdo->prepare("SELECT * FROM appointments WHERE id = :id");
        $stmt->bindParam(':id', $appointmentId, PDO::PARAM_INT);
        $stmt->execute();
        $appointment = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$appointment) {
            throw new Exception("Appointment not found");
        }

        // Update appointment status
        $updateStmt = $pdo->prepare("UPDATE appointments SET status = :status WHERE id = :id");
        $status = ($action === 'accept') ? 'accepted' : 'cancelled';
        $updateStmt->bindParam(':status', $status);
        $updateStmt->bindParam(':id', $appointmentId, PDO::PARAM_INT);
        $updateStmt->execute();

        // Create PHPMailer instance
        $mail = new PHPMailer(true);

        // SMTP configuration
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->Host = 'smtp.gmail.com';
        $mail->Username = 'kaiqi168168@gmail.com';
        $mail->Password = 'eewxujyvnywceyfd';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Email content based on action
        if ($action === 'accept') {
            $mail->Subject = 'Health Care Clinic Appointment Confirmed';
            $bodyContent = "
            <h3>Your Appointment Has Been Confirmed</h3>
            <p>Dear {$appointment['patient_name']},</p>
            <p>Your appointment has been confirmed with the following details:</p>
            <ul>
                <li><strong>Date:</strong> {$appointment['appointment_date']}</li>
                <li><strong>Time:</strong> {$appointment['appointment_time']}</li>
                <li><strong>Doctor:</strong> {$appointment['doctor_id']}</li>
            </ul>
            <p>We look forward to seeing you!</p>
            ";
        } else {
            $mail->Subject = 'Health Care Clinic Appointment Cancelled';
            $bodyContent = "
            <h3>Appointment Cancellation Notice</h3>
            <p>Dear {$appointment['patient_name']},</p>
            <p>We regret to inform you that your appointment has been cancelled.</p>
            <ul>
                <li><strong>Date:</strong> {$appointment['appointment_date']}</li>
                <li><strong>Time:</strong> {$appointment['appointment_time']}</li>
            </ul>
            <p>Please contact our office for further assistance.</p>
            ";
        }

        // Email configuration
        $mail->setFrom('kaiqi168168@gmail.com', 'Clinic Appointment System');
        $mail->addAddress($appointment['email'], $appointment['patient_name']);
        $mail->isHTML(true);
        $mail->Body = $bodyContent;

        // Send email
        $mail->send();

        // Return success response
        return json_encode([
            'status' => 'success', 
            'message' => ($action === 'accept') ? 'Appointment confirmed' : 'Appointment cancelled'
        ]);

    } catch (Exception $e) {
        // Return error response
        return json_encode([
            'status' => 'error', 
            'message' => $e->getMessage()
        ]);
    }
}

// Handle AJAX request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['appointmentId']) && isset($_POST['action'])) {
        $appointmentId = $_POST['appointmentId'];
        $action = $_POST['action'];
        echo sendPatientEmail($appointmentId, $action);
    } else {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Invalid request parameters'
        ]);
    }
}
?>