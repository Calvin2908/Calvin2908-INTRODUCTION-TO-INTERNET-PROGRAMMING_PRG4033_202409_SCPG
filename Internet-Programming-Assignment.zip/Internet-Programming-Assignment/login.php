<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$username = trim(filter_input(INPUT_POST, 'username'));
$password = trim(filter_input(INPUT_POST, 'password'));

if (!empty($username) && !empty($password)) {
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "healthcare";

    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        die(json_encode(['status' => 'error', 'message' => 'Connection Error: ' . $conn->connect_error]));
    } else {
        // Prepare statement to prevent SQL injection and retrieve user type and approval status
        $stmt = $conn->prepare("SELECT user_type, approval_status, password FROM `new account` WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            // Fetch the user details
            $user = $result->fetch_assoc();
            $user_type = $user['user_type'];
            $approval_status = $user['approval_status'];
            $stored_password = $user['password'];

            // Check approval status for doctor and admin
            if (($user_type === 'doctor' || $user_type === 'admin') && $approval_status !== 'accepted') {
                echo json_encode(['status' => 'pending', 'message' => 'Your account is pending approval.']);
            } else {
                // Check the password directly (no hashing)
                if ($password === $stored_password) {
                    // Login successful, set session variables
                    $_SESSION['username'] = $username;
                    $_SESSION['usertype'] = $user_type;

                    // Redirect based on user type
                    switch ($user_type) {
                        case 'admin':
                            echo json_encode(['status' => 'success', 'redirect' => 'home_admin.html']);
                            break;
                        case 'doctor':
                            echo json_encode(['status' => 'success', 'redirect' => 'home_doctor.html']);
                            break;
                        case 'patient':
                            echo json_encode(['status' => 'success', 'redirect' => 'home.html']);
                            break;
                    }
                } else {
                    // Incorrect password
                    echo json_encode(['status' => 'error', 'message' => 'Invalid username or password.']);
                }
            }
        } else {
            // Login failed: User not found
            echo json_encode(['status' => 'error', 'message' => 'Invalid username or password.']);
        }

        $stmt->close();
        $conn->close();
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Please enter both username and password.']);
}
?>
