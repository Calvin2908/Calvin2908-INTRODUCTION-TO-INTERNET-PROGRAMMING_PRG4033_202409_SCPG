<?php
// Enable error reporting
ini_set('display_errors', 1); 
error_reporting(E_ALL);

// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'healthcare';

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle GET request to fetch account requests
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $pdo->prepare("SELECT * FROM `new account` WHERE approval_status = 'pending'");
        $stmt->execute();
        $accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Return accounts as JSON
        if ($accounts) {
            echo json_encode($accounts);
        } else {
            echo json_encode([]); // Empty array if no accounts found
        }
        exit;
    }

    // Handle POST request to update account approval status
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $accountId = $_POST['accountId']; // Account ID
        $action = $_POST['action']; // Action (either 'accept' or 'cancel')

        // Determine the new approval status based on the action
        $status = ($action === 'accept') ? 'accepted' : 'cancelled';

        // Prepare and execute the update statement for approval_status
        $stmt = $pdo->prepare("UPDATE `new account` SET approval_status = :status WHERE Id = :id");
        $stmt->execute([':status' => $status, ':id' => $accountId]);

        // Return success message as JSON
        echo json_encode(['status' => 'success', 'message' => 'Account request ' . $status . '.']);
        exit;
    }

} catch (PDOException $e) {
    // Log error and return error message
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
}
?>
