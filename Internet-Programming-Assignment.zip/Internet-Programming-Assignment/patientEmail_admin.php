<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'healthcare';

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch pending appointments
    $stmt = $pdo->prepare("SELECT * FROM appointments WHERE status = 'pending' ORDER BY appointment_date, appointment_time");
    $stmt->execute();
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Pass data as JSON to be used in the HTML
header('Content-Type: application/json');
echo json_encode($appointments);
?>