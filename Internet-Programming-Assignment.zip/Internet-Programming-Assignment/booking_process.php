<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'healthcare';

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve data from POST request
        $doctorId = $_POST['doctorId'];
        $name = $_POST['name'];
        $ic = $_POST['ic'];
        $email = $_POST['email'];
        $contactnum = $_POST['contact'];

        // Parse the selected date and time
        $selectedDate = $_POST['selectedDate'];
        $selectedTime = $_POST['selectedTime'];

        // Convert date and time to the correct format
        $date = date('Y-m-d', strtotime($selectedDate));
        $time = date('H:i:s', strtotime($selectedTime));

        // Prepare an SQL statement
        $stmt = $pdo->prepare("INSERT INTO appointments (doctor_id, patient_name, nric_passport_no, email, contact_number, appointment_date, appointment_time) VALUES (?, ?, ?, ?, ?, ?, ?)");
        
        // Execute the statement
        if ($stmt->execute([$doctorId, $name, $ic, $email, $contactnum, $date, $time])) {
            echo 'success';
        } else {
            echo 'Failed to book appointment. Please try again.';
        }
    }
} catch (PDOException $e) {
    echo 'Database error: ' . $e->getMessage();
}
?>