<?php
// Sanitize and filter input
$username = trim(filter_input(INPUT_POST, 'username'));
$password = trim(filter_input(INPUT_POST, 'password'));
$email = trim(filter_input(INPUT_POST, 'email'));
$userType = trim(filter_input(INPUT_POST, 'userType'));

// Validate inputs
if (!empty($username) && !empty($password) && !empty($email) && !empty($userType)) {
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "healthcare";

    // Establish database connection
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        echo "Connection Error: " . $conn->connect_error;
        exit();
    }

    // Validate user type
    $validUserTypes = ['patient', 'doctor', 'admin'];
    if (!in_array($userType, $validUserTypes)) {
        echo "Invalid user type selected.";
        $conn->close();
        exit();
    }

    // Prepare statement to check for existing username or email
    $stmt = $conn->prepare("SELECT * FROM `new account` WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Username or email already exists. Please use a different one.";
        $stmt->close();
        $conn->close();
        exit();
    }

    // Insert the plain text password directly
    $plainPassword = $password;

    // Determine approval status based on user type
    $approvalStatus = ($userType === 'patient') ? 'approved' : 'pending';

    // Prepare statement to insert new account with user type and approval status
    $stmt = $conn->prepare("INSERT INTO `new account` (username, password, email, user_type, approval_status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $plainPassword, $email, $userType, $approvalStatus);

    if ($stmt->execute()) {
        // Provide different messages based on user type
        if ($userType === 'doctor') {
            echo "Doctor account created. Please wait for admin approval to access the system.";
        } elseif ($userType === 'admin') {
            echo "Admin account created. Please wait for admin approval to access the system.";
        } else {
            echo "success";
        }
    } else {
        echo "Error!!: " . $stmt->error;
    }

    // Close statements and connection
    $stmt->close();
    $conn->close();
} else {
    echo "All fields are required.";
}
?>
